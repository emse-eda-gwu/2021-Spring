Data file: us_coffee_shops.csv

Date downloaded: March 10, 2020

Description: Data on locations of coffee shops in the U.S. found in this articles
https://media.thinknum.com/articles/coffee-shops-of-america-an-interactive-map/

Source of downloaded file: File was sent to me by Justin Zhen <jzhen@thinknum.com> of thinknum.com
